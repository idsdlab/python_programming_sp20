Typical python games
======

This is a project using python 3 and pygame to implement some popular kinds of games, esp. the classic arcade games (e.g. Raiden)

A list of games is shown as follows:
Pong
brickbreaker
Raiden
